﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel15 = New Panel()
        Button9 = New Button()
        Button8 = New Button()
        Button7 = New Button()
        Label2 = New Label()
        TextBox1 = New TextBox()
        TableLayoutPanel1 = New TableLayoutPanel()
        Label23 = New Label()
        Label22 = New Label()
        Label21 = New Label()
        Label20 = New Label()
        Label19 = New Label()
        Label18 = New Label()
        Label17 = New Label()
        Label16 = New Label()
        Label14 = New Label()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Panel2 = New Panel()
        Label1 = New Label()
        Panel1 = New Panel()
        Label15 = New Label()
        Button6 = New Button()
        Button5 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        PictureBox2 = New PictureBox()
        Panel15.SuspendLayout()
        TableLayoutPanel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel15
        ' 
        Panel15.BackColor = Color.OliveDrab
        Panel15.Controls.Add(Button9)
        Panel15.Controls.Add(Button8)
        Panel15.Controls.Add(Button7)
        Panel15.Controls.Add(Label2)
        Panel15.Controls.Add(TextBox1)
        Panel15.Controls.Add(TableLayoutPanel1)
        Panel15.Dock = DockStyle.Fill
        Panel15.ForeColor = SystemColors.InfoText
        Panel15.Location = New Point(281, 151)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(839, 437)
        Panel15.TabIndex = 11
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Button9.Location = New Point(215, 359)
        Button9.Name = "Button9"
        Button9.Size = New Size(112, 34)
        Button9.TabIndex = 28
        Button9.Text = "Details"
        Button9.UseVisualStyleBackColor = False
        ' 
        ' Button8
        ' 
        Button8.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Button8.Location = New Point(494, 359)
        Button8.Name = "Button8"
        Button8.Size = New Size(112, 34)
        Button8.TabIndex = 27
        Button8.Text = "Delete"
        Button8.UseVisualStyleBackColor = False
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Button7.Location = New Point(354, 359)
        Button7.Name = "Button7"
        Button7.Size = New Size(112, 34)
        Button7.TabIndex = 26
        Button7.Text = "Edit"
        Button7.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Label2.Location = New Point(54, 47)
        Label2.Name = "Label2"
        Label2.Size = New Size(69, 25)
        Label2.TabIndex = 25
        Label2.Text = "Search"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(127, 44)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(305, 31)
        TextBox1.TabIndex = 24
        ' 
        ' TableLayoutPanel1
        ' 
        TableLayoutPanel1.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        TableLayoutPanel1.ColumnCount = 5
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.Controls.Add(Label23, 4, 3)
        TableLayoutPanel1.Controls.Add(Label22, 3, 3)
        TableLayoutPanel1.Controls.Add(Label21, 2, 3)
        TableLayoutPanel1.Controls.Add(Label20, 1, 3)
        TableLayoutPanel1.Controls.Add(Label19, 0, 3)
        TableLayoutPanel1.Controls.Add(Label18, 4, 2)
        TableLayoutPanel1.Controls.Add(Label17, 3, 2)
        TableLayoutPanel1.Controls.Add(Label16, 2, 2)
        TableLayoutPanel1.Controls.Add(Label14, 1, 2)
        TableLayoutPanel1.Controls.Add(Label13, 0, 2)
        TableLayoutPanel1.Controls.Add(Label12, 4, 1)
        TableLayoutPanel1.Controls.Add(Label11, 3, 1)
        TableLayoutPanel1.Controls.Add(Label10, 2, 1)
        TableLayoutPanel1.Controls.Add(Label9, 1, 1)
        TableLayoutPanel1.Controls.Add(Label8, 0, 1)
        TableLayoutPanel1.Controls.Add(Label7, 4, 0)
        TableLayoutPanel1.Controls.Add(Label6, 3, 0)
        TableLayoutPanel1.Controls.Add(Label5, 2, 0)
        TableLayoutPanel1.Controls.Add(Label4, 0, 0)
        TableLayoutPanel1.Controls.Add(Label3, 1, 0)
        TableLayoutPanel1.Location = New Point(54, 93)
        TableLayoutPanel1.Name = "TableLayoutPanel1"
        TableLayoutPanel1.RowCount = 5
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Percent, 20F))
        TableLayoutPanel1.Size = New Size(734, 235)
        TableLayoutPanel1.TabIndex = 23
        TableLayoutPanel1.UseWaitCursor = True
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Dock = DockStyle.Fill
        Label23.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label23.Location = New Point(587, 141)
        Label23.Name = "Label23"
        Label23.Size = New Size(144, 47)
        Label23.TabIndex = 45
        Label23.Text = "P 2008"
        Label23.TextAlign = ContentAlignment.MiddleLeft
        Label23.UseWaitCursor = True
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Dock = DockStyle.Fill
        Label22.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label22.Location = New Point(441, 141)
        Label22.Name = "Label22"
        Label22.Size = New Size(140, 47)
        Label22.TabIndex = 44
        Label22.Text = "09123456787"
        Label22.TextAlign = ContentAlignment.MiddleLeft
        Label22.UseWaitCursor = True
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Dock = DockStyle.Fill
        Label21.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label21.Location = New Point(295, 141)
        Label21.Name = "Label21"
        Label21.Size = New Size(140, 47)
        Label21.TabIndex = 43
        Label21.Text = "Local Client"
        Label21.TextAlign = ContentAlignment.MiddleLeft
        Label21.UseWaitCursor = True
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Dock = DockStyle.Fill
        Label20.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label20.Location = New Point(149, 141)
        Label20.Name = "Label20"
        Label20.Size = New Size(140, 47)
        Label20.TabIndex = 42
        Label20.Text = "Client Name"
        Label20.TextAlign = ContentAlignment.MiddleLeft
        Label20.UseWaitCursor = True
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Dock = DockStyle.Fill
        Label19.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label19.Location = New Point(3, 141)
        Label19.Name = "Label19"
        Label19.Size = New Size(140, 47)
        Label19.TabIndex = 41
        Label19.Text = "1003"
        Label19.TextAlign = ContentAlignment.MiddleLeft
        Label19.UseWaitCursor = True
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Dock = DockStyle.Fill
        Label18.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label18.Location = New Point(587, 94)
        Label18.Name = "Label18"
        Label18.Size = New Size(144, 47)
        Label18.TabIndex = 40
        Label18.Text = "P 1009"
        Label18.TextAlign = ContentAlignment.MiddleLeft
        Label18.UseWaitCursor = True
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Dock = DockStyle.Fill
        Label17.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label17.Location = New Point(441, 94)
        Label17.Name = "Label17"
        Label17.Size = New Size(140, 47)
        Label17.TabIndex = 39
        Label17.Text = "09123456780"
        Label17.TextAlign = ContentAlignment.MiddleLeft
        Label17.UseWaitCursor = True
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Dock = DockStyle.Fill
        Label16.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label16.Location = New Point(295, 94)
        Label16.Name = "Label16"
        Label16.Size = New Size(140, 47)
        Label16.TabIndex = 38
        Label16.Text = "Foreign Client"
        Label16.TextAlign = ContentAlignment.MiddleLeft
        Label16.UseWaitCursor = True
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Dock = DockStyle.Fill
        Label14.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label14.Location = New Point(149, 94)
        Label14.Name = "Label14"
        Label14.Size = New Size(140, 47)
        Label14.TabIndex = 37
        Label14.Text = "Client Name"
        Label14.TextAlign = ContentAlignment.MiddleLeft
        Label14.UseWaitCursor = True
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Dock = DockStyle.Fill
        Label13.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label13.Location = New Point(3, 94)
        Label13.Name = "Label13"
        Label13.Size = New Size(140, 47)
        Label13.TabIndex = 36
        Label13.Text = "1002"
        Label13.TextAlign = ContentAlignment.MiddleLeft
        Label13.UseWaitCursor = True
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Dock = DockStyle.Fill
        Label12.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label12.Location = New Point(587, 47)
        Label12.Name = "Label12"
        Label12.Size = New Size(144, 47)
        Label12.TabIndex = 35
        Label12.Text = "P 10089"
        Label12.TextAlign = ContentAlignment.MiddleLeft
        Label12.UseWaitCursor = True
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Dock = DockStyle.Fill
        Label11.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label11.Location = New Point(441, 47)
        Label11.Name = "Label11"
        Label11.Size = New Size(140, 47)
        Label11.TabIndex = 34
        Label11.Text = "09123456789"
        Label11.TextAlign = ContentAlignment.MiddleLeft
        Label11.UseWaitCursor = True
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Dock = DockStyle.Fill
        Label10.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label10.Location = New Point(295, 47)
        Label10.Name = "Label10"
        Label10.Size = New Size(140, 47)
        Label10.TabIndex = 33
        Label10.Text = "Local Client"
        Label10.TextAlign = ContentAlignment.MiddleLeft
        Label10.UseWaitCursor = True
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Dock = DockStyle.Fill
        Label9.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label9.Location = New Point(149, 47)
        Label9.Name = "Label9"
        Label9.Size = New Size(140, 47)
        Label9.TabIndex = 32
        Label9.Text = "Client Name"
        Label9.TextAlign = ContentAlignment.MiddleLeft
        Label9.UseWaitCursor = True
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Dock = DockStyle.Fill
        Label8.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label8.Location = New Point(3, 47)
        Label8.Name = "Label8"
        Label8.Size = New Size(140, 47)
        Label8.TabIndex = 31
        Label8.Text = "1001"
        Label8.TextAlign = ContentAlignment.MiddleLeft
        Label8.UseWaitCursor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Dock = DockStyle.Fill
        Label7.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label7.Location = New Point(587, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(144, 47)
        Label7.TabIndex = 30
        Label7.Text = "Balance"
        Label7.TextAlign = ContentAlignment.MiddleLeft
        Label7.UseWaitCursor = True
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Dock = DockStyle.Fill
        Label6.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label6.Location = New Point(441, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(140, 47)
        Label6.TabIndex = 29
        Label6.Text = "Mobile No."
        Label6.TextAlign = ContentAlignment.MiddleLeft
        Label6.UseWaitCursor = True
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Dock = DockStyle.Fill
        Label5.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label5.Location = New Point(295, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(140, 47)
        Label5.TabIndex = 28
        Label5.Text = "Type"
        Label5.TextAlign = ContentAlignment.MiddleLeft
        Label5.UseWaitCursor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Dock = DockStyle.Fill
        Label4.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label4.Location = New Point(3, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(140, 47)
        Label4.TabIndex = 27
        Label4.Text = "Client ID"
        Label4.TextAlign = ContentAlignment.MiddleLeft
        Label4.UseWaitCursor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Dock = DockStyle.Fill
        Label3.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label3.Location = New Point(149, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(140, 47)
        Label3.TabIndex = 26
        Label3.Text = "Name"
        Label3.TextAlign = ContentAlignment.MiddleLeft
        Label3.UseWaitCursor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel2.Controls.Add(Label1)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(281, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(839, 151)
        Panel2.TabIndex = 10
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Tahoma", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label1.Location = New Point(223, 50)
        Label1.Name = "Label1"
        Label1.Size = New Size(435, 58)
        Label1.TabIndex = 0
        Label1.Text = "LIST OF CLIENTS"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel1.Controls.Add(Label15)
        Panel1.Controls.Add(Button6)
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Button4)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(281, 588)
        Panel1.TabIndex = 9
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(304, 309)
        Label15.Name = "Label15"
        Label15.Size = New Size(89, 25)
        Label15.TabIndex = 3
        Label15.Text = "Product 2"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.YellowGreen
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = Color.Black
        Button6.Location = New Point(58, 411)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 34)
        Button6.TabIndex = 16
        Button6.Text = "Employees"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.YellowGreen
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = Color.Black
        Button5.Location = New Point(58, 366)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 34)
        Button5.TabIndex = 15
        Button5.Text = "Vendors"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.YellowGreen
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = Color.Black
        Button4.Location = New Point(58, 315)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 34)
        Button4.TabIndex = 14
        Button4.Text = "Clients"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.YellowGreen
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = Color.Black
        Button3.Location = New Point(58, 267)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 34)
        Button3.TabIndex = 13
        Button3.Text = "Sales Report"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.YellowGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(58, 217)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 34)
        Button2.TabIndex = 12
        Button2.Text = "Products"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.YellowGreen
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(58, 167)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 34)
        Button1.TabIndex = 11
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.OliveDrab
        PictureBox2.BackgroundImageLayout = ImageLayout.None
        PictureBox2.Dock = DockStyle.Top
        PictureBox2.Image = My.Resources.Resources._334893374_1284553268794967_3187038752484035069_n
        PictureBox2.Location = New Point(0, 0)
        PictureBox2.Margin = New Padding(0)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(281, 151)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 10
        PictureBox2.TabStop = False
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1120, 588)
        Controls.Add(Panel15)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "Form5"
        Text = "Form5"
        Panel15.ResumeLayout(False)
        Panel15.PerformLayout()
        TableLayoutPanel1.ResumeLayout(False)
        TableLayoutPanel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
End Class
