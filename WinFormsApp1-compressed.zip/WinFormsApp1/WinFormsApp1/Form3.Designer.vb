﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel15 = New Panel()
        Button9 = New Button()
        Button8 = New Button()
        Button7 = New Button()
        Panel2 = New Panel()
        Label1 = New Label()
        Panel1 = New Panel()
        Label15 = New Label()
        Button6 = New Button()
        Button5 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        PictureBox2 = New PictureBox()
        BackgroundWorker1 = New ComponentModel.BackgroundWorker()
        DataGridView1 = New DataGridView()
        Panel15.SuspendLayout()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel15
        ' 
        Panel15.BackColor = Color.OliveDrab
        Panel15.Controls.Add(DataGridView1)
        Panel15.Controls.Add(Button9)
        Panel15.Controls.Add(Button8)
        Panel15.Controls.Add(Button7)
        Panel15.Dock = DockStyle.Fill
        Panel15.ForeColor = SystemColors.InfoText
        Panel15.Location = New Point(281, 151)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(820, 361)
        Panel15.TabIndex = 5
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.Khaki
        Button9.Location = New Point(518, 293)
        Button9.Name = "Button9"
        Button9.Size = New Size(112, 34)
        Button9.TabIndex = 19
        Button9.Text = "Delete"
        Button9.UseVisualStyleBackColor = False
        ' 
        ' Button8
        ' 
        Button8.BackColor = Color.Khaki
        Button8.Location = New Point(351, 293)
        Button8.Name = "Button8"
        Button8.Size = New Size(112, 34)
        Button8.TabIndex = 18
        Button8.Text = "Edit"
        Button8.UseVisualStyleBackColor = False
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.Khaki
        Button7.Location = New Point(181, 293)
        Button7.Name = "Button7"
        Button7.Size = New Size(112, 34)
        Button7.TabIndex = 17
        Button7.Text = "Add"
        Button7.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel2.Controls.Add(Label1)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(281, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(820, 151)
        Panel2.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Tahoma", 24.0F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label1.Location = New Point(184, 54)
        Label1.Name = "Label1"
        Label1.Size = New Size(493, 58)
        Label1.TabIndex = 0
        Label1.Text = "LIST OF PRODUCTS"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel1.Controls.Add(Label15)
        Panel1.Controls.Add(Button6)
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Button4)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(281, 512)
        Panel1.TabIndex = 3
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(304, 309)
        Label15.Name = "Label15"
        Label15.Size = New Size(89, 25)
        Label15.TabIndex = 3
        Label15.Text = "Product 2"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.YellowGreen
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = Color.Black
        Button6.Location = New Point(58, 411)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 34)
        Button6.TabIndex = 16
        Button6.Text = "Employees"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.YellowGreen
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = Color.Black
        Button5.Location = New Point(58, 366)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 34)
        Button5.TabIndex = 15
        Button5.Text = "Vendors"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.YellowGreen
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = Color.Black
        Button4.Location = New Point(58, 315)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 34)
        Button4.TabIndex = 14
        Button4.Text = "Clients"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.YellowGreen
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = Color.Black
        Button3.Location = New Point(58, 267)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 34)
        Button3.TabIndex = 13
        Button3.Text = "Sales"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.YellowGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(58, 217)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 34)
        Button2.TabIndex = 12
        Button2.Text = "Products"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.YellowGreen
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI Emoji", 9.0F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(58, 167)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 34)
        Button1.TabIndex = 11
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.OliveDrab
        PictureBox2.BackgroundImageLayout = ImageLayout.None
        PictureBox2.Dock = DockStyle.Top
        PictureBox2.Image = My.Resources.Resources._334893374_1284553268794967_3187038752484035069_n
        PictureBox2.Location = New Point(0, 0)
        PictureBox2.Margin = New Padding(0)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(281, 151)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 10
        PictureBox2.TabStop = False
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(40, 39)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 62
        DataGridView1.RowTemplate.Height = 33
        DataGridView1.Size = New Size(747, 231)
        DataGridView1.TabIndex = 20
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(10.0F, 25.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1101, 512)
        Controls.Add(Panel15)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "Form3"
        Text = "Form3"
        Panel15.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents DataGridView1 As DataGridView
End Class
