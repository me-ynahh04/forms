﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel15 = New Panel()
        dgreport = New DataGridView()
        Panel2 = New Panel()
        Label1 = New Label()
        Button7 = New Button()
        Panel1 = New Panel()
        Button10 = New Button()
        Label15 = New Label()
        Button6 = New Button()
        Button5 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        PictureBox2 = New PictureBox()
        btnPrint = New Button()
        Panel15.SuspendLayout()
        CType(dgreport, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel15
        ' 
        Panel15.BackColor = Color.OliveDrab
        Panel15.Controls.Add(dgreport)
        Panel15.Dock = DockStyle.Fill
        Panel15.Location = New Point(281, 151)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(831, 378)
        Panel15.TabIndex = 5
        ' 
        ' dgreport
        ' 
        dgreport.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgreport.Location = New Point(32, 39)
        dgreport.Name = "dgreport"
        dgreport.RowHeadersWidth = 62
        dgreport.RowTemplate.Height = 33
        dgreport.Size = New Size(763, 287)
        dgreport.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel2.Controls.Add(btnPrint)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(Button7)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(281, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(831, 151)
        Panel2.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Tahoma", 20F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label1.Location = New Point(284, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(263, 48)
        Label1.TabIndex = 20
        Label1.Text = "EMPLOYEES"
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.YellowGreen
        Button7.FlatStyle = FlatStyle.Flat
        Button7.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button7.ForeColor = Color.Black
        Button7.Location = New Point(150, 94)
        Button7.Name = "Button7"
        Button7.Size = New Size(166, 38)
        Button7.TabIndex = 19
        Button7.Text = "Import CSV"
        Button7.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel1.Controls.Add(Button10)
        Panel1.Controls.Add(Label15)
        Panel1.Controls.Add(Button6)
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Button4)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(281, 529)
        Panel1.TabIndex = 3
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.YellowGreen
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button10.ForeColor = Color.Black
        Button10.Location = New Point(58, 462)
        Button10.Name = "Button10"
        Button10.Size = New Size(162, 34)
        Button10.TabIndex = 18
        Button10.Text = "Backup"
        Button10.UseVisualStyleBackColor = False
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(304, 309)
        Label15.Name = "Label15"
        Label15.Size = New Size(89, 25)
        Label15.TabIndex = 3
        Label15.Text = "Product 2"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.YellowGreen
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = Color.Black
        Button6.Location = New Point(58, 411)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 34)
        Button6.TabIndex = 16
        Button6.Text = "Employees"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.YellowGreen
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = Color.Black
        Button5.Location = New Point(58, 366)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 34)
        Button5.TabIndex = 15
        Button5.Text = "Vendors"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.YellowGreen
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = Color.Black
        Button4.Location = New Point(58, 315)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 34)
        Button4.TabIndex = 14
        Button4.Text = "Clients"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.YellowGreen
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = Color.Black
        Button3.Location = New Point(58, 267)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 34)
        Button3.TabIndex = 13
        Button3.Text = "Sales"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.YellowGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(58, 217)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 34)
        Button2.TabIndex = 12
        Button2.Text = "Products"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.YellowGreen
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(58, 167)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 34)
        Button1.TabIndex = 11
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.OliveDrab
        PictureBox2.BackgroundImageLayout = ImageLayout.None
        PictureBox2.Dock = DockStyle.Top
        PictureBox2.Image = My.Resources.Resources._334893374_1284553268794967_3187038752484035069_n
        PictureBox2.Location = New Point(0, 0)
        PictureBox2.Margin = New Padding(0)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(281, 151)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 10
        PictureBox2.TabStop = False
        ' 
        ' btnPrint
        ' 
        btnPrint.BackColor = Color.YellowGreen
        btnPrint.FlatStyle = FlatStyle.Flat
        btnPrint.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        btnPrint.ForeColor = Color.Black
        btnPrint.Location = New Point(518, 94)
        btnPrint.Name = "btnPrint"
        btnPrint.Size = New Size(166, 38)
        btnPrint.TabIndex = 21
        btnPrint.Text = "Print"
        btnPrint.UseVisualStyleBackColor = False
        ' 
        ' Form7
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1112, 529)
        Controls.Add(Panel15)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "Form7"
        Text = "Form7"
        Panel15.ResumeLayout(False)
        CType(dgreport, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button10 As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button7 As Button
    Friend WithEvents dgreport As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents btnPrint As Button
End Class
