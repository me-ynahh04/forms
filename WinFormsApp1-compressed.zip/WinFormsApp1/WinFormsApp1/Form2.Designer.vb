﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Panel1 = New Panel()
        Button10 = New Button()
        Label15 = New Label()
        Button6 = New Button()
        Button5 = New Button()
        Button4 = New Button()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        PictureBox2 = New PictureBox()
        Panel2 = New Panel()
        Panel13 = New Panel()
        Label11 = New Label()
        Panel14 = New Panel()
        Label12 = New Label()
        Panel11 = New Panel()
        Label9 = New Label()
        Panel12 = New Panel()
        Label10 = New Label()
        Panel9 = New Panel()
        Label7 = New Label()
        Panel10 = New Panel()
        Label8 = New Label()
        Panel7 = New Panel()
        Label5 = New Label()
        Panel8 = New Panel()
        Label6 = New Label()
        Panel3 = New Panel()
        Panel5 = New Panel()
        Label3 = New Label()
        Panel6 = New Panel()
        Label4 = New Label()
        Label2 = New Label()
        Panel4 = New Panel()
        Label1 = New Label()
        PageSetupDialog1 = New PageSetupDialog()
        ContextMenuStrip1 = New ContextMenuStrip(components)
        Panel15 = New Panel()
        Panel16 = New Panel()
        Label20 = New Label()
        Panel17 = New Panel()
        DateTimePicker1 = New DateTimePicker()
        CheckedListBox1 = New CheckedListBox()
        Label19 = New Label()
        LinkLabel1 = New LinkLabel()
        Label18 = New Label()
        Label17 = New Label()
        Label16 = New Label()
        Label14 = New Label()
        Panel1.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        Panel13.SuspendLayout()
        Panel14.SuspendLayout()
        Panel11.SuspendLayout()
        Panel12.SuspendLayout()
        Panel9.SuspendLayout()
        Panel10.SuspendLayout()
        Panel7.SuspendLayout()
        Panel8.SuspendLayout()
        Panel3.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        Panel4.SuspendLayout()
        Panel15.SuspendLayout()
        Panel16.SuspendLayout()
        Panel17.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel1.Controls.Add(Button10)
        Panel1.Controls.Add(Label15)
        Panel1.Controls.Add(Button6)
        Panel1.Controls.Add(Button5)
        Panel1.Controls.Add(Button4)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(281, 508)
        Panel1.TabIndex = 0
        ' 
        ' Button10
        ' 
        Button10.BackColor = Color.YellowGreen
        Button10.FlatStyle = FlatStyle.Flat
        Button10.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button10.ForeColor = Color.Black
        Button10.Location = New Point(58, 462)
        Button10.Name = "Button10"
        Button10.Size = New Size(162, 34)
        Button10.TabIndex = 18
        Button10.Text = "Backup"
        Button10.UseVisualStyleBackColor = False
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(304, 309)
        Label15.Name = "Label15"
        Label15.Size = New Size(89, 25)
        Label15.TabIndex = 3
        Label15.Text = "Product 2"
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.YellowGreen
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button6.ForeColor = Color.Black
        Button6.Location = New Point(58, 411)
        Button6.Name = "Button6"
        Button6.Size = New Size(162, 34)
        Button6.TabIndex = 16
        Button6.Text = "Employees"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.YellowGreen
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button5.ForeColor = Color.Black
        Button5.Location = New Point(58, 366)
        Button5.Name = "Button5"
        Button5.Size = New Size(162, 34)
        Button5.TabIndex = 15
        Button5.Text = "Vendors"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.YellowGreen
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button4.ForeColor = Color.Black
        Button4.Location = New Point(58, 315)
        Button4.Name = "Button4"
        Button4.Size = New Size(162, 34)
        Button4.TabIndex = 14
        Button4.Text = "Clients"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.YellowGreen
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button3.ForeColor = Color.Black
        Button3.Location = New Point(58, 267)
        Button3.Name = "Button3"
        Button3.Size = New Size(162, 34)
        Button3.TabIndex = 13
        Button3.Text = "Sales"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.YellowGreen
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button2.ForeColor = Color.Black
        Button2.Location = New Point(58, 217)
        Button2.Name = "Button2"
        Button2.Size = New Size(162, 34)
        Button2.TabIndex = 12
        Button2.Text = "Products"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.YellowGreen
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Button1.ForeColor = Color.Black
        Button1.Location = New Point(58, 167)
        Button1.Name = "Button1"
        Button1.Size = New Size(162, 34)
        Button1.TabIndex = 11
        Button1.Text = "Dashboard"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.OliveDrab
        PictureBox2.BackgroundImageLayout = ImageLayout.None
        PictureBox2.Dock = DockStyle.Top
        PictureBox2.Image = My.Resources.Resources._334893374_1284553268794967_3187038752484035069_n
        PictureBox2.Location = New Point(0, 0)
        PictureBox2.Margin = New Padding(0)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(281, 151)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 10
        PictureBox2.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(192), CByte(235), CByte(192))
        Panel2.Controls.Add(Panel13)
        Panel2.Controls.Add(Panel11)
        Panel2.Controls.Add(Panel9)
        Panel2.Controls.Add(Panel7)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(281, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(801, 151)
        Panel2.TabIndex = 1
        ' 
        ' Panel13
        ' 
        Panel13.BorderStyle = BorderStyle.FixedSingle
        Panel13.Controls.Add(Label11)
        Panel13.Controls.Add(Panel14)
        Panel13.Location = New Point(636, 10)
        Panel13.Name = "Panel13"
        Panel13.Size = New Size(149, 90)
        Panel13.TabIndex = 4
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label11.ForeColor = Color.IndianRed
        Label11.Location = New Point(46, 50)
        Label11.Name = "Label11"
        Label11.Size = New Size(52, 25)
        Label11.TabIndex = 1
        Label11.Text = "1000"
        ' 
        ' Panel14
        ' 
        Panel14.BackColor = Color.YellowGreen
        Panel14.BorderStyle = BorderStyle.FixedSingle
        Panel14.Controls.Add(Label12)
        Panel14.Dock = DockStyle.Top
        Panel14.Location = New Point(0, 0)
        Panel14.Name = "Panel14"
        Panel14.Size = New Size(147, 38)
        Panel14.TabIndex = 1
        Panel14.Tag = ""
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(48, 5)
        Label12.Name = "Label12"
        Label12.Size = New Size(52, 25)
        Label12.TabIndex = 0
        Label12.Text = "Sales"
        ' 
        ' Panel11
        ' 
        Panel11.BorderStyle = BorderStyle.FixedSingle
        Panel11.Controls.Add(Label9)
        Panel11.Controls.Add(Panel12)
        Panel11.Location = New Point(482, 9)
        Panel11.Name = "Panel11"
        Panel11.Size = New Size(149, 90)
        Panel11.TabIndex = 3
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.ForeColor = Color.IndianRed
        Label9.Location = New Point(50, 50)
        Label9.Name = "Label9"
        Label9.Size = New Size(42, 25)
        Label9.TabIndex = 1
        Label9.Text = "450"
        ' 
        ' Panel12
        ' 
        Panel12.BackColor = Color.YellowGreen
        Panel12.BorderStyle = BorderStyle.FixedSingle
        Panel12.Controls.Add(Label10)
        Panel12.Dock = DockStyle.Top
        Panel12.Location = New Point(0, 0)
        Panel12.Name = "Panel12"
        Panel12.Size = New Size(147, 38)
        Panel12.TabIndex = 1
        Panel12.Tag = ""
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(32, 5)
        Label10.Name = "Label10"
        Label10.Size = New Size(82, 25)
        Label10.TabIndex = 0
        Label10.Text = "Products"
        ' 
        ' Panel9
        ' 
        Panel9.BorderStyle = BorderStyle.FixedSingle
        Panel9.Controls.Add(Label7)
        Panel9.Controls.Add(Panel10)
        Panel9.Location = New Point(328, 9)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(149, 90)
        Panel9.TabIndex = 2
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.ForeColor = Color.IndianRed
        Label7.Location = New Point(57, 50)
        Label7.Name = "Label7"
        Label7.Size = New Size(32, 25)
        Label7.TabIndex = 1
        Label7.Text = "65"
        ' 
        ' Panel10
        ' 
        Panel10.BackColor = Color.YellowGreen
        Panel10.BorderStyle = BorderStyle.FixedSingle
        Panel10.Controls.Add(Label8)
        Panel10.Dock = DockStyle.Top
        Panel10.Location = New Point(0, 0)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(147, 38)
        Panel10.TabIndex = 1
        Panel10.Tag = ""
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(32, 5)
        Label8.Name = "Label8"
        Label8.Size = New Size(85, 25)
        Label8.TabIndex = 0
        Label8.Text = "Suppliers"
        Label8.TextAlign = ContentAlignment.TopCenter
        ' 
        ' Panel7
        ' 
        Panel7.BorderStyle = BorderStyle.FixedSingle
        Panel7.Controls.Add(Label5)
        Panel7.Controls.Add(Panel8)
        Panel7.Location = New Point(173, 9)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(149, 90)
        Panel7.TabIndex = 2
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = Color.IndianRed
        Label5.Location = New Point(52, 50)
        Label5.Name = "Label5"
        Label5.Size = New Size(42, 25)
        Label5.TabIndex = 1
        Label5.Text = "150"
        ' 
        ' Panel8
        ' 
        Panel8.BackColor = Color.YellowGreen
        Panel8.BorderStyle = BorderStyle.FixedSingle
        Panel8.Controls.Add(Label6)
        Panel8.Dock = DockStyle.Top
        Panel8.Location = New Point(0, 0)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(147, 38)
        Panel8.TabIndex = 1
        Panel8.Tag = ""
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(25, 5)
        Label6.Name = "Label6"
        Label6.Size = New Size(98, 25)
        Label6.TabIndex = 0
        Label6.Text = "Employees"
        ' 
        ' Panel3
        ' 
        Panel3.BorderStyle = BorderStyle.FixedSingle
        Panel3.Controls.Add(Panel5)
        Panel3.Controls.Add(Label2)
        Panel3.Controls.Add(Panel4)
        Panel3.Location = New Point(18, 9)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(149, 90)
        Panel3.TabIndex = 1
        ' 
        ' Panel5
        ' 
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(Label3)
        Panel5.Controls.Add(Panel6)
        Panel5.Location = New Point(169, -1)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(149, 90)
        Panel5.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.IndianRed
        Label3.Location = New Point(50, 50)
        Label3.Name = "Label3"
        Label3.Size = New Size(42, 25)
        Label3.TabIndex = 1
        Label3.Text = "200"
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.Wheat
        Panel6.BorderStyle = BorderStyle.FixedSingle
        Panel6.Controls.Add(Label4)
        Panel6.Dock = DockStyle.Top
        Panel6.Location = New Point(0, 0)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(147, 38)
        Panel6.TabIndex = 1
        Panel6.Tag = ""
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(39, 5)
        Label4.Name = "Label4"
        Label4.Size = New Size(64, 25)
        Label4.TabIndex = 0
        Label4.Text = "Clients"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = Color.IndianRed
        Label2.Location = New Point(50, 50)
        Label2.Name = "Label2"
        Label2.Size = New Size(42, 25)
        Label2.TabIndex = 1
        Label2.Text = "200"
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.YellowGreen
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(Label1)
        Panel4.Dock = DockStyle.Top
        Panel4.Location = New Point(0, 0)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(147, 38)
        Panel4.TabIndex = 1
        Panel4.Tag = ""
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(39, 5)
        Label1.Name = "Label1"
        Label1.Size = New Size(64, 25)
        Label1.TabIndex = 0
        Label1.Text = "Clients"
        ' 
        ' ContextMenuStrip1
        ' 
        ContextMenuStrip1.ImageScalingSize = New Size(24, 24)
        ContextMenuStrip1.Name = "ContextMenuStrip1"
        ContextMenuStrip1.Size = New Size(61, 4)
        ' 
        ' Panel15
        ' 
        Panel15.BackColor = Color.OliveDrab
        Panel15.Controls.Add(Panel16)
        Panel15.Controls.Add(Label14)
        Panel15.Dock = DockStyle.Fill
        Panel15.Location = New Point(281, 151)
        Panel15.Name = "Panel15"
        Panel15.Size = New Size(801, 357)
        Panel15.TabIndex = 2
        ' 
        ' Panel16
        ' 
        Panel16.BackColor = Color.YellowGreen
        Panel16.Controls.Add(Label20)
        Panel16.Controls.Add(Panel17)
        Panel16.Controls.Add(LinkLabel1)
        Panel16.Controls.Add(Label18)
        Panel16.Controls.Add(Label17)
        Panel16.Controls.Add(Label16)
        Panel16.Dock = DockStyle.Bottom
        Panel16.Location = New Point(0, 116)
        Panel16.Name = "Panel16"
        Panel16.Size = New Size(801, 241)
        Panel16.TabIndex = 3
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Trebuchet MS", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label20.Location = New Point(88, 21)
        Label20.Name = "Label20"
        Label20.Size = New Size(205, 26)
        Label20.TabIndex = 8
        Label20.Text = "Message Notification"
        ' 
        ' Panel17
        ' 
        Panel17.Controls.Add(DateTimePicker1)
        Panel17.Controls.Add(CheckedListBox1)
        Panel17.Controls.Add(Label19)
        Panel17.Dock = DockStyle.Right
        Panel17.Location = New Point(386, 0)
        Panel17.Name = "Panel17"
        Panel17.Size = New Size(415, 241)
        Panel17.TabIndex = 5
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.CalendarMonthBackground = Color.OliveDrab
        DateTimePicker1.Location = New Point(54, 184)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(316, 31)
        DateTimePicker1.TabIndex = 9
        ' 
        ' CheckedListBox1
        ' 
        CheckedListBox1.BackColor = Color.GreenYellow
        CheckedListBox1.FormattingEnabled = True
        CheckedListBox1.Items.AddRange(New Object() {"Input assignments", "Other task"})
        CheckedListBox1.Location = New Point(54, 60)
        CheckedListBox1.Name = "CheckedListBox1"
        CheckedListBox1.Size = New Size(316, 144)
        CheckedListBox1.TabIndex = 7
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Trebuchet MS", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Label19.Location = New Point(179, 21)
        Label19.Name = "Label19"
        Label19.Size = New Size(75, 29)
        Label19.TabIndex = 6
        Label19.Text = "To Do"
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Location = New Point(114, 182)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(152, 25)
        LinkLabel1.TabIndex = 4
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Other messages..."
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Segoe UI Variable Text Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label18.ForeColor = Color.Brown
        Label18.Location = New Point(32, 168)
        Label18.Name = "Label18"
        Label18.Size = New Size(0, 27)
        Label18.TabIndex = 3
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Segoe UI Variable Text Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label17.ForeColor = Color.Brown
        Label17.Location = New Point(32, 120)
        Label17.Name = "Label17"
        Label17.Size = New Size(101, 27)
        Label17.TabIndex = 2
        Label17.Text = "- Meeting"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Segoe UI Variable Text Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point)
        Label16.ForeColor = Color.Brown
        Label16.Location = New Point(32, 76)
        Label16.Name = "Label16"
        Label16.Size = New Size(164, 27)
        Label16.TabIndex = 1
        Label16.Text = "- Time to restock"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label14.ForeColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        Label14.Location = New Point(239, 33)
        Label14.Name = "Label14"
        Label14.Size = New Size(345, 43)
        Label14.TabIndex = 2
        Label14.Text = "WELCOME ADMIN"
        ' 
        ' Dashboard
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Beige
        ClientSize = New Size(1082, 508)
        Controls.Add(Panel15)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Name = "Dashboard"
        Text = "Dashboard"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel13.ResumeLayout(False)
        Panel13.PerformLayout()
        Panel14.ResumeLayout(False)
        Panel14.PerformLayout()
        Panel11.ResumeLayout(False)
        Panel11.PerformLayout()
        Panel12.ResumeLayout(False)
        Panel12.PerformLayout()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        Panel10.ResumeLayout(False)
        Panel10.PerformLayout()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel15.ResumeLayout(False)
        Panel15.PerformLayout()
        Panel16.ResumeLayout(False)
        Panel16.PerformLayout()
        Panel17.ResumeLayout(False)
        Panel17.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PageSetupDialog1 As PageSetupDialog
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel17 As Panel
    Friend WithEvents CheckedListBox1 As CheckedListBox
    Friend WithEvents Label19 As Label
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Button10 As Button
End Class
